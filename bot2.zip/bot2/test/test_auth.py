from fastapi.testclient import TestClient
from app.main import app
import uuid

client = TestClient(app)

def test_register_and_login():
    # Уникальный email для каждого запуска
    unique_email = f"test_{uuid.uuid4()}@example.com"

    # Регистрация
    register_response = client.post(
        "/auth/register",
        json={"email": unique_email, "password": "testpassword123"}
    )
    assert register_response.status_code == 200
    token = register_response.json()["access_token"]

    # Логин
    login_response = client.post(
        "/auth/login",
        data={"username": unique_email, "password": "testpassword123"}
    )
    assert login_response.status_code == 200
    assert "access_token" in login_response.json()