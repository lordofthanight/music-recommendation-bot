from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_create_session():
    # Сначала регистрация и логин
    client.post(
        "/auth/register",
        json={"email": "chat@example.com", "password": "testpassword123"}
    )
    login = client.post(
        "/auth/login",
        data={"username": "chat@example.com", "password": "testpassword123"}
    )
    token = login.json()["access_token"]

    # Создание сессии с токеном в query
    response = client.post(
        "/chat/session",
        params={"token": token}  # токен в query-параметре
    )
    assert response.status_code == 200
    assert "id" in response.json()