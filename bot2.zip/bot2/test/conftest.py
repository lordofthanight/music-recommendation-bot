import pytest
from fastapi.testclient import TestClient
from app.main import app

@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c

@pytest.fixture(scope="module")
def test_user():
    return {
        "username": "testuser_fixed",
        "password": "strongpass12345",
        "email": "testuser@example.com"
    }

@pytest.fixture(scope="module")
def auth_token(client, test_user):
    reg_resp = client.post(
    "/auth/register",
    json={
        "username": test_user["username"],
        "password": test_user["password"],
        "email": test_user["email"]
        }
    )
    if reg_resp.status_code not in (200, 201, 409):  # 409 если уже существует
        print("Регистрация failed:", reg_resp.status_code, reg_resp.json())

    # Логин — почти всегда form-data!
    login_resp = client.post(
        "/auth/login",  # или /auth/token — проверь свой роут
        data=test_user  # <--- ВАЖНО: data= для OAuth2PasswordRequestForm
    )
    assert login_resp.status_code == 200
    return login_resp.json()["access_token"]