from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from .models import User, Session, Message

async def get_user_by_email(db: AsyncSession, email: str):
    result = await db.execute(select(User).where(User.email == email))
    return result.scalar_one_or_none()

async def create_user(db: AsyncSession, email: str, hashed_pw: str):
    user = User(email=email, hashed_password=hashed_pw)
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user

async def create_session(db: AsyncSession, user_id: int):
    session = Session(user_id=user_id)
    db.add(session)
    await db.commit()
    await db.refresh(session)
    return session

async def save_message(db: AsyncSession, session_id: int, text: str, is_bot: bool = False):
    message = Message(session_id=session_id, text=text, is_bot=is_bot)
    db.add(message)
    await db.commit()
    await db.refresh(message)
    return message

async def get_session_messages(db: AsyncSession, session_id: int):
    result = await db.execute(select(Message).where(Message.session_id == session_id).order_by(Message.timestamp))
    return result.scalars().all()