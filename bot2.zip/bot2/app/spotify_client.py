import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
from .config import settings

sp = spotipy.Spotify(auth_manager=SpotifyClientCredentials(
    client_id=settings.spotify_client_id,
    client_secret=settings.spotify_client_secret
))