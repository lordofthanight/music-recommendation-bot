# Этот файл делает папку app Python-пакетом
# Можно оставить пустым или добавить импорты для удобства

from .main import app  # Позволяет импортировать app как from app import app
from .routers.auth import router as auth_router
from .routers.chat import router as chat_router

__all__ = ["app", "auth_router", "chat_router"]