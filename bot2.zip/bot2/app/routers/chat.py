from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect, Query, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from ..crud import create_session, save_message, get_session_messages
from ..bot_logic import get_bot_response
from ..schemas import MessageIn, SessionOut
from ..auth import verify_token  # <-- только verify_token
from ..database import get_db

router = APIRouter(prefix="/chat", tags=["chat"])

@router.post("/session", response_model=SessionOut)
async def new_session(token: str = Query(...), db: AsyncSession = Depends(get_db)):
    user_id = verify_token(token)
    session = await create_session(db, user_id)
    return SessionOut(id=session.id, created_at=session.created_at)

@router.get("/history/{session_id}")
async def history(session_id: int, token: str = Query(...), db: AsyncSession = Depends(get_db)):
    user_id = verify_token(token)
    messages = await get_session_messages(db, session_id)
    return [{"text": m.text, "is_bot": m.is_bot, "timestamp": m.timestamp.isoformat()} for m in messages]

@router.websocket("/ws")
async def websocket_chat(websocket: WebSocket, token: str = Query(...), db: AsyncSession = Depends(get_db)):
    await websocket.accept()
    user_id = verify_token(token)
    session = await create_session(db, user_id)

    try:
        while True:
            data = await websocket.receive_json()
            msg = MessageIn(**data)
            if not msg.text.strip():
                continue
            await save_message(db, session.id, msg.text, is_bot=False)
            reply = await get_bot_response(msg.text)
            await save_message(db, session.id, reply, is_bot=True)
            await websocket.send_json({"text": reply, "is_bot": True})
    except WebSocketDisconnect:
        pass