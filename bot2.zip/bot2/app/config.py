from pydantic_settings import BaseSettings
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    database_url: str
    secret_key: str
    spotify_client_id: str
    spotify_client_secret: str

settings = Settings()