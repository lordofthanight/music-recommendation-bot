import asyncio
from .spotify_client import sp

async def get_bot_response(user_text: str) -> str:
    text = user_text.lower()
    if "рекоменд" not in text and "посоветуй" not in text:
        return "Привет! Расскажи, какую музыку хочешь — по настроению или жанру (например: «рекомендуй грустное indie»)"

    energy = 0.6
    if any(word in text for word in ["энергичн", "весел", "танц"]): energy = 0.9
    if any(word in text for word in ["грустн", "спокойн", "chill"]): energy = 0.3

    genre = "pop"
    genres = ["rock", "hip-hop", "electronic", "indie", "classical", "jazz"]
    for g in genres:
        if g in text:
            genre = g
            break

    try:
        results = await asyncio.to_thread(
            sp.recommendations,
            seed_genres=[genre],
            target_energy=energy,
            limit=4,
            market="US"
        )
        tracks = []
        for track in results["tracks"]:
            name = track["name"]
            artists = ", ".join(a["name"] for a in track["artists"])
            url = track["external_urls"]["spotify"]
            tracks.append(f"• {name} — {artists}\n  {url}")
        return f"Рекомендации ({genre}, energy={energy:.2f}):\n\n" + "\n\n".join(tracks)
    except Exception as e:
        return f"Spotify недоступен сейчас. Попробуй позже.\nОшибка: {str(e)[:100]}"