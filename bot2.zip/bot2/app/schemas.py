from pydantic import BaseModel, EmailStr, Field
from datetime import datetime

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8)

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class MessageIn(BaseModel):
    text: str = Field(..., min_length=1, max_length=1000)

class SessionOut(BaseModel):
    id: int
    created_at: datetime